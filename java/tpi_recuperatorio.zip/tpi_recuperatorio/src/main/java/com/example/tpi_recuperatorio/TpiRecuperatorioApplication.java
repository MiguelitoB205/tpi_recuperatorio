package com.example.tpi_recuperatorio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TpiRecuperatorioApplication {

	public static void main(String[] args) {
		SpringApplication.run(TpiRecuperatorioApplication.class, args);
	}

}

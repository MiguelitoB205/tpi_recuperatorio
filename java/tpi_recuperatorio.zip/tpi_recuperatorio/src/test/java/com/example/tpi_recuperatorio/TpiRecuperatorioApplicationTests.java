package com.example.tpi_recuperatorio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpiRecuperatorioApplicationTests {

	@Test
	void contextLoads() {
	}

}
